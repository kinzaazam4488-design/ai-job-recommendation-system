
import pandas as pd
import random

skills = [
"python","sql","machine learning","data analysis","excel","tableau","aws","docker",
"kubernetes","linux","java","javascript","html","css","react","tensorflow","pytorch",
"statistics","nlp","api","git","cloud","cybersecurity","devops","database","mysql",
"mongodb","data visualization","powerbi","deep learning","flask","django","c++",
"network security","ethical hacking"
]

job_titles = [
"Data Analyst","Data Scientist","Machine Learning Engineer",
"Web Developer","Backend Developer","Frontend Developer",
"Software Engineer","Cloud Engineer","DevOps Engineer",
"Cyber Security Analyst","Database Administrator"
]

education_levels = ["Bachelor","Master","PhD"]
experience_levels = ["Junior","Mid","Senior"]

jobs = []
for i in range(100):
    jobs.append({
        "job_id": i,
        "job_title": random.choice(job_titles),
        "skills": ",".join(random.sample(skills, random.randint(3,6))),
        "education": random.choice(education_levels),
        "experience": random.choice(experience_levels),
        "salary": random.randint(50000,150000)
    })

pd.DataFrame(jobs).to_csv("data/datasets/jobs.csv", index=False)

users = []
for i in range(50):
    users.append({
        "user_id": i,
        "name": f"user_{i}",
        "skills": ",".join(random.sample(skills, random.randint(2,5))),
        "education": random.choice(education_levels),
        "experience": random.choice(experience_levels)
    })

pd.DataFrame(users).to_csv("data/datasets/users.csv", index=False)

skills_demand = []
for s in skills:
    skills_demand.append({
        "skill": s,
        "demand_score": random.randint(50,100)
    })

pd.DataFrame(skills_demand).to_csv("data/datasets/skills_demand.csv", index=False)

print("Datasets generated successfully")
