
import pandas as pd
from sklearn.preprocessing import LabelEncoder

jobs = pd.read_csv("data/datasets/jobs.csv")
users = pd.read_csv("data/datasets/users.csv")

jobs["skills"] = jobs["skills"].str.lower()
users["skills"] = users["skills"].str.lower()

jobs["skills_list"] = jobs["skills"].apply(lambda x: x.split(","))
users["skills_list"] = users["skills"].apply(lambda x: x.split(","))

edu_encoder = LabelEncoder()
exp_encoder = LabelEncoder()

jobs["education_encoded"] = edu_encoder.fit_transform(jobs["education"])
jobs["experience_encoded"] = exp_encoder.fit_transform(jobs["experience"])

users["education_encoded"] = edu_encoder.fit_transform(users["education"])
users["experience_encoded"] = exp_encoder.fit_transform(users["experience"])

jobs.to_csv("data/datasets/jobs_cleaned.csv", index=False)
users.to_csv("data/datasets/users_cleaned.csv", index=False)

print("Preprocessing complete")
print("Jobs:", jobs.shape)
print("Users:", users.shape)
