
from models.recommendation_engine import recommend_jobs

while True:
    print("\nAI Job Recommendation System")
    skills = input("Enter your skills (or type exit): ")

    if skills == "exit":
        break

    print(recommend_jobs(skills))
