
print("Running complete pipeline...")

import subprocess

subprocess.run(["python","data/data_generator.py"])
subprocess.run(["python","data/data_preprocessor.py"])
subprocess.run(["python","visualization/analytics_dashboard.py"])
subprocess.run(["python","visualization/report_generator.py"])

print("System ready. Run interactive_recommender.py for demo.")
