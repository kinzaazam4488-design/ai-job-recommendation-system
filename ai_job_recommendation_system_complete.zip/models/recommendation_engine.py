
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

jobs = pd.read_csv("data/datasets/jobs_cleaned.csv")

vectorizer = TfidfVectorizer()
skill_matrix = vectorizer.fit_transform(jobs["skills"])

def recommend_jobs(user_skills):

    user_vec = vectorizer.transform([user_skills])
    similarity = cosine_similarity(user_vec, skill_matrix)
    scores = similarity.flatten()
    top = scores.argsort()[-5:][::-1]

    results = jobs.iloc[top][["job_title","skills"]]
    return results

if __name__ == "__main__":
    skills = input("Enter your skills: ")
    print(recommend_jobs(skills))
