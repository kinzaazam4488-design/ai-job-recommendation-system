
import pandas as pd

jobs = pd.read_csv("data/datasets/jobs_cleaned.csv")

def skill_gap(user_skills):
    user_set = set(user_skills.split(","))

    job = jobs.sample(1).iloc[0]
    job_skills = set(job["skills"].split(","))

    missing = job_skills - user_set

    print("Target Job:", job["job_title"])
    print("Missing Skills:", list(missing))

if __name__ == "__main__":
    s = input("Enter your skills separated by comma: ")
    skill_gap(s)
