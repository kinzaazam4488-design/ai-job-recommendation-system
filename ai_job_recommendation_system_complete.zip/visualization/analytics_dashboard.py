
import pandas as pd
import matplotlib.pyplot as plt

skills = pd.read_csv("data/datasets/jobs.csv")["skills"].str.split(",").explode()

skills.value_counts().head(10).plot(kind="bar")
plt.title("Top Skills in Job Market")
plt.tight_layout()

plt.savefig("visualizations/top_skills.png")
print("Visualization saved to visualizations/top_skills.png")
