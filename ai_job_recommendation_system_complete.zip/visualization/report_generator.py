
import pandas as pd

users = pd.read_csv("data/datasets/users.csv")

for i,row in users.head(5).iterrows():
    report = f'''
User Report
Name: {row["name"]}
Skills: {row["skills"]}
Education: {row["education"]}
Experience: {row["experience"]}
'''
    with open(f"reports/report_{i}.txt","w") as f:
        f.write(report)

print("Sample reports generated")
